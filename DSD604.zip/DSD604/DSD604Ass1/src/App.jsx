import React from 'react';
import Game from './components/game.jsx';  

function App() {
  return (
    <div>
      <h1>Maori Place name quiz</h1>
      <Game />
    </div>
  );
}

export default App;
